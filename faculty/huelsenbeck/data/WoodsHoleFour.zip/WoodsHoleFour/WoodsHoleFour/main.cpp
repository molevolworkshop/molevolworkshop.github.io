#include <cmath>
#include <iomanip>
#include <iostream>
#include "RandomVariable.h"


/*  This program implements the Metropolis-Hastings algorithm (Metropolis
    et al., 1953; Hastings, 1970) for a simple coin-tossing situation. The
    idea is that you have tossed a coin numTosses times and observed numHeads
    heads. The likelihood is a binomial probability distribution whereas the
    prior is assumed to be a uniform prior on the interval (0,1). A uniform(0,1)
    prior is equivalent to a Beta(alpha,beta) prior, where alpha = beta = 1.0.
    Interestingly, the Beta probability distribution is a conjugate prior for
    a binomial likelihood. This means that the posterior probability distribution
    is also a Beta, but with parameters alpha+numHeads and beta+numTails.
    
    The individual steps of the Metropolis-Hastings algorithm are as follows:

    1. Call the current value of the Markov chain theta. If this is the
       first cycle of the chain, initialize theta to some value.
    2. Propose a new value for theta, called thetaPrime. This proposal
       mechanism must involve random numbers. The probability of making
       the move from theta to thetaPrime is called q(theta -> thetaPrime).
       The probability of the reverse move, which isn't actually made in
       computer memory, is q(thetaPrime -> theta).
    3. Calculate the probability of accepting thetaPrime as the next state 
       of the chain:
       
          R = min(1, LikelihoodRatio X Prior Ratio X Proposal Ratio)
 
    4. Generate a Uniform(0,1) random variable called u. If u < R, then
       set theta = thetaPrime. O/w, the chain remains in state theta.
    5. Go to Step # 2. */

int main(int argc, const char * argv[]) {

    // user interface (this is the lamest user interface ever)
    int numTosses      = 100;                  // number of times coin was tossed
    int numHeads       = 43;                   // number of heads observed
    int numTails       = numTosses - numHeads; // number of tails observed
    int chainLength    = 10000;                // how many MCMC cycles to run the chain
    double window      = 0.1;                  // size of the window for proposing new values
    int printFrequency = 10;                   // how often to print the state of the chain

    // instantiate the random variable object for random numbers
    RandomVariable rv;
    
    // run the Markov chain Monte Carlo algorithm
    double theta = rv.uniformRv();
    int bins[100];  // we will use this array to keep track of where the chain goes
    for (int i=0; i<100; i++)
        bins[i] = 0;
    for (int n=1; n<=chainLength; n++)
        {
        // propose a new value for theta, called thetaPrime, using the sliding
        // window mechanism
        double thetaPrime = theta + (rv.uniformRv() - 0.5) * window;
        if (thetaPrime < 0.0)
            thetaPrime = -thetaPrime;
        else if (thetaPrime > 1.0)
            thetaPrime = 2.0 - thetaPrime;
        
        // calculate the probability of accepting thetaPrime as the
        // next state of the Markov chain
        double lnLikelihooRatio = (numHeads * log(thetaPrime) + numTails * log(1.0-thetaPrime)) -
                                  (numHeads * log(theta     ) + numTails * log(1.0-theta     ));
        double lnPriorRatio = 0.0;
        double lnProposalRatio = 0.0;
        double lnR = lnLikelihooRatio + lnPriorRatio + lnProposalRatio;
        double R = 0.0;
        if (lnR > 0.0)
            R = 1.0;
        else if (lnR < -300.0)
            R = 0.0;
        else
            R = exp(lnR);
        
        // accept or reject thetaPrime
        double u = rv.uniformRv();
        if (u < R)
            theta = thetaPrime;
            
        // where was the chain?
        bins[ (int)(theta*100.0) ]++;
       
        // print the state of the chain to the screen
        if (n % printFrequency == 0)
            {
            std::cout << n << " -- " << thetaPrime << std::endl;
            }
        }

    // print the frequency histogram
    double sum = 0.0;
    for (int i=0; i<100; i++)
        {
        sum += (double)bins[i] / chainLength;
        double exactProbability = rv.betaCdf(1.0+numHeads, 1.0+numTails, (i+1)*0.01) - rv.betaCdf(1.0+numHeads, 1.0+numTails, i*0.01);
        
        std::cout << std::fixed << std::setprecision(2);
        std::cout << i*0.01 << " - " << (i+1)*0.01 << " -- ";
        std::cout << std::setw(5) << bins[i] << " ";
        std::cout << std::fixed << std::setprecision(4);
        std::cout << (double)bins[i] / chainLength << " ";
        std::cout << sum << " ";
        std::cout << exactProbability << " ";
        std::cout << std::endl;
        }

    return 0;
}
