#include <cmath>
#include <ctime>
#include <iostream>
#include "RandomVariable.h"


RandomVariable::RandomVariable(void) {

    seed = (long int)time(NULL);
}

RandomVariable::RandomVariable(long int x) {

    seed = x;
}

double RandomVariable::uniformRv(void) {

	long int hi = seed / 127773;
	long int lo = seed % 127773;
	long int test = 16807 * lo - 2836 * hi;
	if (test > 0)
		seed = test;
	else
		seed = test + 2147483647;
	return (double)(seed) / (double)2147483647;
}

double RandomVariable::beta(double a, double b) {

	return ( exp(lnGamma(a) + lnGamma(b) - lnGamma(a + b)) );
}

double RandomVariable::betaCdf(double a, double b, double x) {

	double cdf;
	if ( x <= 0.0 )
		cdf = 0.0;
	else if ( x <= 1.0 )
		cdf = incompleteBeta(a, b, x);
	else
		cdf = 1.0;
	return cdf;
}

double RandomVariable::lnGamma(double a) {

	double x = a;
	double f = 0.0;
	double z;
	if (x < 7) 
		{
		f = 1.0;  
		z = x - 1.0;
		while (++z < 7.0)  
			f *= z;
		x = z;   
		f = -log(f);
		}
	z = 1.0 / (x*x);
	return  (f + (x-0.5)*log(x) - x + 0.918938533204673 + 
			(((-0.000595238095238*z+0.000793650793651)*z-0.002777777777778)*z +
			0.083333333333333)/x);  
}

double RandomVariable::incompleteBeta(double a, double b, double x) {

	double tol = 1.0E-07;

	double value;
	if ( x <= 0.0 )
		{
		value = 0.0;
		return value;
		}
	else if ( 1.0 <= x )
		{
		value = 1.0;
		return value;
		}

	/* change tail if necessary and determine S */
	double psq = a + b;

	double xx, cx, pp, qq;
	bool indx;
	if ( a < (a + b) * x )
		{
		xx = 1.0 - x;
		cx = x;
		pp = b;
		qq = a;
		indx = true;
		}
	else
		{
		xx = x;
		cx = 1.0 - x;
		pp = a;
		qq = b;
		indx = false;
		}

	double term = 1.0;
	int i = 1;
	value = 1.0;
	int ns = (int)(qq + cx * (a + b));

	/* use Soper's reduction formulas */
	double rx = xx / cx;

	double temp = qq - (double)i;
	if ( ns == 0 )
		rx = xx;

	int it = 0;
	int it_max = 1000;
	for (;;)
		{
		it++;
		if ( it_max < it )
			{
			std::cout << "Error in incompleteBeta: Maximum number of iterations exceeded!" << std::endl;
			std::exit(1);
			//ui->error("Error in incompleteBeta: Maximum number of iterations exceeded!");
			//throw(MbException(MbException::ERROR));
			}
		term = term * temp * rx / ( pp + ( double ) ( i ) );
		value = value + term;
		temp = fabs(term);
		if ( temp <= tol && temp <= tol * value )
			break;
		i++;
		ns--;
		if ( 0 <= ns )
			{
			temp = qq - (double)i;
			if ( ns == 0 )
				rx = xx;
			}
		else
			{
			temp = psq;
			psq = psq + 1.0;
			}
		}
		
	/* finish calculation */
	value = value * exp(pp * log(xx) + (qq - 1.0) * log(cx)) / (beta(a, b) * pp);
	if ( indx )
		value = 1.0 - value;
	return value;
}

double RandomVariable::uniformRv(double lowerLimit, double upperLimit) {

    if (lowerLimit > upperLimit)
        {
        std::cout << "Error: You are a complete idiot!" << std::endl;
        exit(1);
        }
        
    double u = uniformRv();
    double newU = lowerLimit + (upperLimit - lowerLimit) * u;
    
    return newU;
}

double RandomVariable::exponentialRv(double lambda) {

    double u = uniformRv();
    double t = -(1.0 / lambda) * log(u);
    return t;
}
