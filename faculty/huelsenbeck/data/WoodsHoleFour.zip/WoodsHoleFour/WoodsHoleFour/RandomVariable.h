#ifndef RandomVariable_h
#define RandomVariable_h


class RandomVariable {

    public:
                    RandomVariable(void);
                    RandomVariable(long int x);
        double      betaCdf(double a, double b, double x);
        double      uniformRv(void);
        double      uniformRv(double lowerLimit, double upperLimit);
        double      exponentialRv(double lambda);
    
    private:
        double      beta(double a, double b);
        double      incompleteBeta(double a, double b, double x);
        double      lnGamma(double a);
        long int    seed;
};


#endif
