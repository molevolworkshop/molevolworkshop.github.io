//
//  Woods Hole MCMC v1.0
//
//  A program for approximating the posterior probability distribution of
//  the probability of heads for a coin.
//
//  Created by John Huelsenbeck on 7/25/12.
//
#include <cmath>
#include <iomanip>
#include <iostream>
#include "MbRandom.h"



int main(int argc, char* argv[]) {

    // lame user interface
    int numHeads    = 47;
    int numTosses   = 100;
    int chainLength = 100000;
    double window   = 0.1;
    int numTails    = numTosses - numHeads;
    std::cout << "Number of heads = " << numHeads << std::endl;
    std::cout << "Number of tails = " << numTails << std::endl;
    
    // get a random number generator (avert your eyes!!!)
    MbRandom myRandom;
    
    // make a variable that will keep track of where the chain has been
    int bins[100];
    for (int i=0; i<100; i++)
        bins[i] = 0;
    
    // do the MCMC cycles
    double theta = myRandom.uniformRv();
    for (int n=1; n<=chainLength; n++)
        {
        // propose a new value for theta
        double thetaPrime = theta + (myRandom.uniformRv() - 0.5) * window;
        if (thetaPrime < 0.0)
            thetaPrime = -thetaPrime;
        else if (thetaPrime > 1.0)
            thetaPrime = 2.0 - thetaPrime;
            
        // calculate the probability of accepting thetaPrime as the next
        // state of the Markov chain
        double lnLikelihoodRatio = (numHeads*log(thetaPrime)+numTails*log(1.0-thetaPrime)) -
                                   (numHeads*log(theta     )+numTails*log(1.0-theta     ));
        double lnPriorRatio = 0.0;
        double lnProposalRatio = 0.0;
        double lnR = lnLikelihoodRatio + lnPriorRatio + lnProposalRatio;
        double R = 0.0;
        if (lnR > 0.0)
            R = 1.0;
        else if (lnR < -300.0)
            R = 0.0;
        else
            R = exp(lnR);
            
        // accept/reject the proposed state
        double u = myRandom.uniformRv();
        if (u < R)
            {
            // Accept the state...weeeee
            theta = thetaPrime;
            }
        else
            {
            // Reject the state :-(
            }
            
        // where has the chain been?
        bins[(int)(theta*100.0)]++;
        
        std::cout << n << " " << theta << std::endl;
        }
    
    // At this point in the code the MCMC algorithm has completed. Let's looked
    // at the frequency histogram showing where the chain went.
    double sum = 0.0;
    for (int i=0; i<100; i++)
        {
        std::cout << std::fixed << std::setprecision(2) << i*0.01 << " - " << (i+1)*0.01 << " ";
        std::cout << std::fixed << std::setprecision(4) << (double)bins[i] / chainLength << " ";
        double exactIntervalProb = myRandom.betaCdf(numHeads+1, numTails+1, (i+1)*0.01) - 
                                   myRandom.betaCdf(numHeads+1, numTails+1, (i  )*0.01);
        std::cout << std::fixed << std::setprecision(4) << exactIntervalProb << " ";
        sum += (double)bins[i] / chainLength;
        std::cout << std::fixed << std::setprecision(4) << sum << " ";
        std::cout << std::endl;
        }

    return 0;
}

